import { Component } from '@angular/core';


export class ActionComponent {
    
}
