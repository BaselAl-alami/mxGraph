import { Component } from '@angular/core';

@Component({
  selector: 'uml-app',
  templateUrl: './umlapp.component.html',
  styleUrls: ['./umlapp.component.css']
})
export class UmlComponent {
  title = 'uml app';
}
