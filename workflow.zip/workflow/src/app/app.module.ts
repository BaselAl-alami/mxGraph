import { UmlComponent } from './umlapp/umlapp.component';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { EditorComponent} from '../app/editorComponent/editor.component';
import { AppComponent } from './app.component';

@NgModule({
  declarations: [
    AppComponent,
    UmlComponent,
    EditorComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [UmlComponent]
})
export class AppModule { }
