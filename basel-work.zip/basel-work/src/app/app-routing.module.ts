import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { Shape01Component } from './components/shape01/shape01.component';
import { Shape02Component } from './components/shape02/shape02.component';
import { Shape03Component } from './components/shape03/shape03.component';
import { Shape05Component } from './components/shape05/shape05.component';


const routes: Routes = [
  { path: 'shape01', component: Shape01Component },
  { path: 'shape02', component: Shape02Component },
  { path: 'shape03', component: Shape03Component },
  { path: 'shape05', component: Shape05Component },

  { path: '', redirectTo: '/shape04', pathMatch: 'full' }	
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
