import { Component, OnInit, AfterViewInit, ViewChild, ElementRef } from '@angular/core';

import { mxgraph } from "mxgraph";

declare var require: any;
const mx = require('mxgraph')({
  mxImageBasePath: 'assets/mxgraph/images',
  mxBasePath: 'assets/mxgraph'
});

@Component({
  selector: 'app-shape05',
  templateUrl: './shape05.component.html',
  styleUrls: ['./shape05.component.css']
})
export class Shape05Component implements AfterViewInit {
 

	@ViewChild('graphContainer') container: ElementRef;


	ngAfterViewInit(): void {
  
		  // Creates the div for the toolbar
	  var tbContainer = document.createElement('div');
	  tbContainer.style.position = 'absolute';
	  tbContainer.style.overflow = 'hidden';
	  tbContainer.style.padding = '2px';
	  tbContainer.style.left = '0px';
	  tbContainer.style.top = '26px';
	  tbContainer.style.width = '24px';
	  tbContainer.style.bottom = '0px';
	  //we append tbContainer inside the document
	  document.body.appendChild(tbContainer);
	
	  // Creates new toolbar without event processing  
	  //(the toolbar variable represent the toolbar tab)
	  var toolbar = new mx.mxToolbar(tbContainer);
	  toolbar.enabled = false;
  
	  // Workaround for Internet Explorer ignoring certain styles
	  if (mx.mxClient.IS_QUIRKS)
	  {
		document.body.style.overflow = 'hidden';
		//we make the toolbar tab resizable
		new mx.mxDivResizer(tbContainer);
		//we make the DIV container resizable
		new mx.mxDivResizer(this.container);
	  }
  
	  // Creates the model and the graph inside the container
	  // using the fastest rendering available on the browser
	  var model = new mx.mxGraphModel();
	  var graph = new mx.mxGraph(this.container.nativeElement, model);
	  //we enable dragable inside the mxGraph
	  graph.dropEnabled = true;




	  mx.mxEvent.addListener(this.container.nativeElement, 'dragover', function(evt)
      {
		  debugger;
        if (graph.isEnabled())
        {
          evt.stopPropagation();
          evt.preventDefault();
        }
      });
  
      //we apply Drop event on the graph
	  mx.mxDragSource.prototype.getDropTarget = function(graph, x, y)
	  {
		var cell = graph.getCellAt(x, y);
		
		if (!graph.isValidDropTarget(cell))
		{
		  cell = null;
		}
		console.log('Value Is : ', cell);
		return cell;
	  };
  
	  // Enables new connections in the graph
	  graph.setConnectable(true);
	  graph.setMultigraph(false);
  
	  // Stops editing on enter or escape keypress
	  var keyHandler = new mx.mxKeyHandler(graph);
	  var rubberband = new mx.mxRubberband(graph);
	  
	  //this function is used to add images inside toolbar
	  var addVertex = function(icon, w, h, style)
	  {
		//geometry: mxGeometry
		//height: 200,width: 200,x: 0,y: 0,__proto__: mxRectangle,style: 
		//"shape=swimlane;startSize=20;value: null,vertex: false
		var vertex = new mx.mxCell(null, new mx.mxGeometry(0, 0, w, h), style);
		//we set property vertex as vertex shape (by default )
		//vertex: true
		vertex.setVertex(true);
		//the below command is used to add vertex (mxCell) inside the graph
  
  
		//toolbar : represent the toolbar tab 
		//graph   : represent the graph editor
		//vertex  : represent the mxCell that inserted in th toolbar tab
		//icon    : represent the icon that represent the design of the shapes
		addToolbarItem(graph, toolbar, vertex, icon);
	  };
	 
	  setStyle(graph);




	  //The below command is used to assign shapes in the toolbar with assign style for each image
	  addVertex('../../../assets/images/swimlane.gif', 1000, 200, 'swimlane');
	  addVertex('../../../assets/images/rectangle.gif', 100, 100, 'process');   
	  addVertex('../../../assets/images/ellipse.gif', 100, 100, 'start');
	  addVertex('../../../assets/images/rhombus.gif', 100, 100, 'condition');
	  addVertex('../../../assets/images/ellipse.gif', 100, 100, 'end');
  
	  //this below command is add line in the toolbar
		toolbar.addLine();


		graph.popupMenuHandler.factoryMethod = function (menu, cell, evt) {
			return createPopupMenu(graph, menu, cell, evt);
		};



      //creates a key handler that listens to the delete key (46) 
      //and deletes the selection cells if the graph is enabled.
		var keyHandler = new mx.mxKeyHandler(graph);
		keyHandler.bindKey(46, function (evt) {
			debugger;
			if (graph.isEnabled()) {
				graph.removeCells();
			}
		});

		
  
	  //-------------------------Make custom shapes----------------------------------------/
	  var button = mx.mxUtils.button('Create toolbar entry from selection', function(evt)
	  {
		if (!graph.isSelectionEmpty())
		{
		  // Creates a copy of the selection array to preserve its state
		  var cells = graph.getSelectionCells();
		  var bounds = graph.getView().getBounds(cells);
		  
		  // Function that is executed when the image is dropped on
		  // the graph. The cell argument points to the cell under
		  // the mousepointer if there is one.
		  var funct = function(graph, evt, cell)
		  {
			graph.stopEditing(false);
	
			var pt = graph.getPointForEvent(evt);
			var dx = pt.x - bounds.x;
			var dy = pt.y - bounds.y;
			
			graph.setSelectionCells(graph.importCells(cells, dx, dy, cell));
		  }
	
		  // Creates the image which is used as the drag icon (preview)
		  var img = toolbar.addMode(null, 'editors/images/outline.gif', funct);
		  mx.mxUtils.makeDraggable(img, graph, funct);
		}
	  });
  
	  button.style.position = 'absolute';
	  button.style.left = '2px';
	  button.style.top = '2px';
	  
	  document.body.appendChild(button);
	}
}

function setStyle(graph)
{
	 var style = graph.getStylesheet().getDefaultVertexStyle();

	//we set style for the SHAPE_SWIMLANE on the class name called swimlane
	style = mx.mxUtils.clone(style);
    style[mx.mxConstants.STYLE_SHAPE] = mx.mxConstants.SHAPE_SWIMLANE;
    style[mx.mxConstants.STYLE_VERTICAL_ALIGN] = 'middle';
    style[mx.mxConstants.STYLE_LABEL_BACKGROUNDCOLOR] = 'white';
    style[mx.mxConstants.STYLE_FONTSIZE] = 11;
    style[mx.mxConstants.STYLE_STARTSIZE] = 22;
    style[mx.mxConstants.STYLE_HORIZONTAL] = false;
    style[mx.mxConstants.STYLE_FONTCOLOR] = 'black';
    style[mx.mxConstants.STYLE_STROKECOLOR] = 'black';
    //delete style[mx.mxConstants.STYLE_FILLCOLOR];
    graph.getStylesheet().putCellStyle('swimlane', style);

    // //we set style for the SHAPE_RECT on the class name called process
    style = mx.mxUtils.clone(style);
    style[mx.mxConstants.STYLE_SHAPE] = mx.mxConstants.SHAPE_RECTANGLE;
    style[mx.mxConstants.STYLE_FONTSIZE] = 12;
    style[mx.mxConstants.STYLE_FONTSTYLE] = 1;
    style[mx.mxConstants.STYLE_ROUNDED] = true;
    style[mx.mxConstants.STYLE_HORIZONTAL] = true;
    style[mx.mxConstants.STYLE_VERTICAL_ALIGN] = 'middle';
    delete style[mx.mxConstants.STYLE_STARTSIZE];
    style[mx.mxConstants.STYLE_LABEL_BACKGROUNDCOLOR] = 'none';
    graph.getStylesheet().putCellStyle('process', style);


    // //we set style for the SHAPE_Ellipse on the class name called state
    style = mx.mxUtils.clone(style);
    style[mx.mxConstants.STYLE_SHAPE] = mx.mxConstants.SHAPE_ELLIPSE;
    style[mx.mxConstants.STYLE_PERIMETER] = mx.mxPerimeter.EllipsePerimeter;
    delete style[mx.mxConstants.STYLE_ROUNDED];
    graph.getStylesheet().putCellStyle('start', style);

    //we set style for the SHAPE_RHOMBUS on the class name called condition
    style = mx.mxUtils.clone(style);
    style[mx.mxConstants.STYLE_SHAPE] = mx.mxConstants.SHAPE_RHOMBUS;
    style[mx.mxConstants.STYLE_PERIMETER] = mx.mxPerimeter.RhombusPerimeter;
    // style[mx.mxConstants.STYLE_VERTICAL_ALIGN] = 'top';
    // style[mx.mxConstants.STYLE_SPACING_TOP] = 40;
    // style[mx.mxConstants.STYLE_SPACING_RIGHT] = 64;
    graph.getStylesheet().putCellStyle('condition', style);

    //we set style for the SHAPE_DOUBLE_ELLIPSE on the class name called end
    style = mx.mxUtils.clone(style);
    style[mx.mxConstants.STYLE_SHAPE] = mx.mxConstants.SHAPE_DOUBLE_ELLIPSE;
    style[mx.mxConstants.STYLE_PERIMETER] = mx.mxPerimeter.EllipsePerimeter;
    // style[mx.mxConstants.STYLE_SPACING_TOP] = 28;
    style[mx.mxConstants.STYLE_FONTSIZE] = 12;
    style[mx.mxConstants.STYLE_FONTSTYLE] = 1;
    delete style[mx.mxConstants.STYLE_SPACING_RIGHT];
    graph.getStylesheet().putCellStyle('end', style);

    //we set style of normal arrow line
    style = graph.getStylesheet().getDefaultEdgeStyle();
    style[mx.mxConstants.STYLE_EDGE] = mx.mxEdgeStyle.ElbowConnector;
    style[mx.mxConstants.STYLE_ENDARROW] = mx.mxConstants.ARROW_BLOCK;
    style[mx.mxConstants.STYLE_ROUNDED] = true;
    style[mx.mxConstants.STYLE_FONTCOLOR] = 'black';
    style[mx.mxConstants.STYLE_STROKECOLOR] = 'black';
    graph.getStylesheet().putCellStyle('arrow', style);

    // //we set style of Arrow Open on the class called crossover   like ---------
    // style = mx.mxUtils.clone(style);
    // style[mx.mxConstants.STYLE_DASHED] = true;
    // style[mx.mxConstants.STYLE_ENDARROW] = mx.mxConstants.ARROW_OPEN;
    // style[mx.mxConstants.STYLE_STARTARROW] = mx.mxConstants.ARROW_OVAL;
    // graph.getStylesheet().putCellStyle('crossover', style);

    // // Installs double click on middle control point and
    // // changes style of edges between empty and this value
    // graph.alternateEdgeStyle = 'elbow=vertical';
}

//this function is used to add image inside toolbar
function addToolbarItem(graph, toolbar, prototype, image)
{
  // Function that is executed when the0 image is dropped on
  // the graph. The cell argument points to the cell under
  // the mousepointer if there is one.
  var funct = function(graph, evt, cell)
  {
    graph.stopEditing(false);
    var pt = graph.getPointForEvent(evt);
    debugger;
    var vertex = graph.getModel().cloneCell(prototype);
    vertex.geometry.x = pt.x;
	vertex.geometry.y = pt.y;
	if(cell != null)
	{
		//graph.setSelectionCells(cell.importCells([vertex], 0, 0, cell));

		var graphElement = graph.insertVertex(cell, vertex.id, name,vertex.geometry.x ,vertex.geometry.y, vertex.geometry.width, vertex.geometry.height, vertex.style);

	}
	else
	{
		graph.setSelectionCells(graph.importCells([vertex], 0, 0, cell));
	}
  }
  // Creates the image which is used as the drag icon (preview)
  var img = toolbar.addMode(null, image, funct);
  mx.mxUtils.makeDraggable(img, graph, funct);
}

// Function to create the entries in the popupmenu
function createPopupMenu(graph, menu, cell, evt)
{
	debugger;
	if (cell != null) {

		if (cell.style == "process") {
           fillRectOptions(menu);
		}
		else if (cell.style == "condition") {
           fillConditionOptions(menu);
		}
	}	
};

function fillRectOptions(menu)
{
	menu.addItem('Option Rect', null, function()
	{
		alert('Process Rect 1');
	});
	menu.addItem('Option Rect', null, function()
	{
		alert('Process Rect 1');
	});
	var submenu1 = menu.addItem('Option Subment Rect 01', null, null);

	menu.addItem('Option Subitem 1', null, function()
	  {
	  alert('Subitem Rect 1');
	  }, submenu1);
	menu.addItem('Option Subment Rect 02', null, function()
	  {
	  alert('Subitem Rect 2');
	  }, submenu1);
}

function fillConditionOptions(menu)
{
	menu.addItem('Option Condition 1', null, function()
	{
		alert('Option Condition 1');
	});
	menu.addItem('Option Condition 2', null, function()
	{
		alert('Option Condition 2');
	});
	var submenu1 = menu.addItem('Option Subment Condition 01', null, null);

	menu.addItem('Option Subitem Condition 1', null, function()
	  {
	  alert('Subitem Condition 1');
	  }, submenu1);
	menu.addItem('Option Subment Condition 02', null, function()
	  {
	  alert('Subitem Condition 2');
	  }, submenu1);
}


