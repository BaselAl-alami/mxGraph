import {
  Component,
  OnInit,
  AfterViewInit,
  ViewChild,
  ElementRef
} from "@angular/core";

import { mxgraph } from "mxgraph";

declare var mxClient;
declare var require: any;
declare var mxPoint;
declare var mxUtils;
declare var mxEditor;
declare var mxGraph;
declare var mxEvent;
declare var mxConstants;
declare var mxPerimeter;
declare var mxEdgeStyle;


const mx = require("mxgraph")({
  mxImageBasePath: "assets/mxgraph/images",
  mxBasePath: "assets/mxgraph"
});

@Component({
  selector: "app-shape03",
  templateUrl: "./shape03.component.html",
  styleUrls: ["./shape03.component.css"]
})
export class Shape03Component implements AfterViewInit {
  @ViewChild("toolBarContainer") toolBarContainer: ElementRef;

  ngAfterViewInit() {
    var container = document.getElementById("graphContainer");
    var outline = document.getElementById("outlineContainer");
    var toolbar = this.toolBarContainer.nativeElement;
    var sidebar = document.getElementById("sidebarContainer");
    var status = document.getElementById("statusContainer");
    this.main(container, outline, toolbar, sidebar, status);
  }

  main(container, outline, toolbar, sidebar, status) {
    if (!mxClient.isBrowserSupported()) {
      // Displays an error message if the browser is not supported.
      mxUtils.error("Browser is not supported!", 200, false);
    } else {
      var editor = new mxEditor();
      var graph = editor.graph;
      var model = graph.getModel();

      // Does not allow dangling edges
      graph.setAllowDanglingEdges(false);

      // Sets the graph container and configures the editor
      editor.setGraphContainer(container);
      var config = mxUtils
        .load("assets/images/keyhandler-commons.xml")
        .getDocumentElement();
      editor.configure(config);



      // Returns a shorter label if the cell is collapsed and no
      // label for expanded groups
      graph.getLabel = function(cell) {
        var tmp = mxGraph.prototype.getLabel.apply(this, arguments); // "supercall"

        if (this.isCellLocked(cell)) {
          // Returns an empty label but makes sure an HTML
          // element is created for the label (for event
          // processing wrt the parent label)
          return "";
        } else if (this.isCellCollapsed(cell)) {
          var index = tmp.indexOf("</h1>");

          if (index > 0) {
            tmp = tmp.substring(0, index + 5);
            console.log(tmp);
          }
        }

        return tmp;
      };

      // Shows a "modal" window when double clicking a vertex.
      graph.dblClick = function(evt, cell) {
        // Do not fire a DOUBLE_CLICK event here as mxEditor will
        // consume the event and start the in-place editor.
        if (
          this.isEnabled() &&
          !mxEvent.isConsumed(evt) &&
          cell != null &&
          this.isCellEditable(cell)
        ) {
          if (this.model.isEdge(cell) || !this.isHtmlLabel(cell)) {
            this.startEditingAtCell(cell);
          } else {
            var content = document.createElement("div");
            content.innerHTML = this.convertValueToString(cell);
            this.showModalWindow(this, "Properties", content, 400, 300);
          }
        }

        // Disables any default behaviour for the double click
        mxEvent.consume(evt);
      };

      graph.setConnectable(true);

      // Adds all required styles to the graph (see below)
      this.configureStylesheet(graph);

    }
  }


  configureStylesheet(graph) {
    var style = graph.getStylesheet().getDefaultVertexStyle();
    this.setSwimlaneStyle(style,graph);
    this.setProcessStyle(style,graph);
    this.setStateStyle(style,graph);
    this.setConditionStyle(style,graph);
    this.setEndStyle(style,graph);
    this.setArrowStyle(style,graph);
    this.setCrossoverStyle(style,graph);

    style = new Object();
    style[mxConstants.STYLE_SHAPE] = mxConstants.SHAPE_SWIMLANE;
    style[mxConstants.STYLE_PERIMETER] = mxPerimeter.RectanglePerimeter;
    style[mxConstants.STYLE_ALIGN] = mxConstants.ALIGN_CENTER;
    style[mxConstants.STYLE_VERTICAL_ALIGN] = mxConstants.ALIGN_TOP;
    style[mxConstants.STYLE_FILLCOLOR] = "#FF9103";
    style[mxConstants.STYLE_GRADIENTCOLOR] = "#F8C48B";
    style[mxConstants.STYLE_STROKECOLOR] = "#E86A00";
    style[mxConstants.STYLE_FONTCOLOR] = "#000000";
    style[mxConstants.STYLE_ROUNDED] = true;
    style[mxConstants.STYLE_OPACITY] = "80";
    style[mxConstants.STYLE_STARTSIZE] = "30";
    style[mxConstants.STYLE_FONTSIZE] = "16";
    style[mxConstants.STYLE_FONTSTYLE] = 1;
    graph.getStylesheet().putCellStyle("group", style);

    style = new Object();
    style[mxConstants.STYLE_SHAPE] = mxConstants.SHAPE_IMAGE;
    style[mxConstants.STYLE_FONTCOLOR] = "#774400";
    style[mxConstants.STYLE_PERIMETER] = mxPerimeter.RectanglePerimeter;
    style[mxConstants.STYLE_PERIMETER_SPACING] = "6";
    style[mxConstants.STYLE_ALIGN] = mxConstants.ALIGN_LEFT;
    style[mxConstants.STYLE_VERTICAL_ALIGN] = mxConstants.ALIGN_MIDDLE;
    style[mxConstants.STYLE_FONTSIZE] = "10";
    style[mxConstants.STYLE_FONTSTYLE] = 2;
    style[mxConstants.STYLE_IMAGE_WIDTH] = "16";
    style[mxConstants.STYLE_IMAGE_HEIGHT] = "16";
    graph.getStylesheet().putCellStyle("port", style);

    style = graph.getStylesheet().getDefaultEdgeStyle();
    style[mxConstants.STYLE_LABEL_BACKGROUNDCOLOR] = "#FFFFFF";
    style[mxConstants.STYLE_STROKEWIDTH] = "2";
    style[mxConstants.STYLE_ROUNDED] = true;
    style[mxConstants.STYLE_EDGE] = mxEdgeStyle.EntityRelation;
  }


  setCrossoverStyle(style: any, graph: any) {
    style = mxUtils.clone(style);
     style[mxConstants.STYLE_DASHED] = true;
     style[mxConstants.STYLE_ENDARROW] = mxConstants.ARROW_OPEN;
     style[mxConstants.STYLE_STARTARROW] = mxConstants.ARROW_OVAL;
     graph.getStylesheet().putCellStyle('crossover', style);
  }
  setArrowStyle(style: any, graph: any) {
     style = graph.getStylesheet().getDefaultEdgeStyle();
     style[mxConstants.STYLE_EDGE] = mx.mxEdgeStyle.ElbowConnector;
     style[mxConstants.STYLE_ENDARROW] = mxConstants.ARROW_BLOCK;
     style[mxConstants.STYLE_ROUNDED] = true;
     style[mxConstants.STYLE_FONTCOLOR] = 'black';
     style[mxConstants.STYLE_STROKECOLOR] = 'black';
     graph.getStylesheet().putCellStyle('arrow', style);
  }


  setEndStyle(style: any, graph: any) {
    style = mxUtils.clone(style);
     style[mxConstants.STYLE_SHAPE] = mxConstants.SHAPE_DOUBLE_ELLIPSE;
     style[mxConstants.STYLE_PERIMETER] = mx.mxPerimeter.EllipsePerimeter;
     style[mxConstants.STYLE_SPACING_TOP] = 28;
     style[mxConstants.STYLE_FONTSIZE] = 14;
     style[mxConstants.STYLE_FONTSTYLE] = 1;
     delete style[mxConstants.STYLE_SPACING_RIGHT];
     graph.getStylesheet().putCellStyle('end', style);
  }
  setConditionStyle(style: any, graph: any) {
    style = mxUtils.clone(style);
     style[mxConstants.STYLE_SHAPE] = mxConstants.SHAPE_RHOMBUS;
     style[mxConstants.STYLE_PERIMETER] = mx.mxPerimeter.RhombusPerimeter;
     // style[mxConstants.STYLE_VERTICAL_ALIGN] = 'top';
     // style[mxConstants.STYLE_SPACING_TOP] = 40;
     // style[mxConstants.STYLE_SPACING_RIGHT] = 64;
     graph.getStylesheet().putCellStyle('condition', style);
  }


  setStateStyle(style: any, graph: any) {
    style = mxUtils.clone(style);
    style[mxConstants.STYLE_SHAPE] = mxConstants.SHAPE_ELLIPSE;
    style[mxConstants.STYLE_PERIMETER] = mx.mxPerimeter.EllipsePerimeter;
    delete style[mxConstants.STYLE_ROUNDED];
    graph.getStylesheet().putCellStyle('state', style);

  }


  setProcessStyle(style: any, graph: any) {
    style = mxUtils.clone(style);
    style[mxConstants.STYLE_SHAPE] = mxConstants.SHAPE_RECTANGLE;
    style[mxConstants.STYLE_FONTSIZE] = 10;
    style[mxConstants.STYLE_ROUNDED] = true;
    style[mxConstants.STYLE_HORIZONTAL] = true;
    style[mxConstants.STYLE_VERTICAL_ALIGN] = 'middle';
    delete style[mxConstants.STYLE_STARTSIZE];
    style[mxConstants.STYLE_LABEL_BACKGROUNDCOLOR] = 'none';
    graph.getStylesheet().putCellStyle('process', style);
  }


  setSwimlaneStyle(style: any, graph: any) {
    style[mxConstants.STYLE_SHAPE] = mxConstants.SHAPE_SWIMLANE;
    style[mxConstants.STYLE_VERTICAL_ALIGN] = 'middle';
    style[mxConstants.STYLE_LABEL_BACKGROUNDCOLOR] = 'white';
    style[mxConstants.STYLE_FONTSIZE] = 11;
    style[mxConstants.STYLE_STARTSIZE] = 22;
    style[mxConstants.STYLE_HORIZONTAL] = false;
    style[mxConstants.STYLE_FONTCOLOR] = 'black';
    style[mxConstants.STYLE_STROKECOLOR] = 'black';
    //delete style[mxConstants.STYLE_FILLCOLOR];
    graph.getStylesheet().putCellStyle('swimlane', style);
  }
}
