import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { Shape01Component } from './components/shape01/shape01.component';
import { Shape02Component } from './components/shape02/shape02.component';
import { Shape03Component } from './components/shape03/shape03.component';
import { Shape04Component } from './components/shape04/shape04.component';
import { Shape05Component } from './components/shape05/shape05.component';


@NgModule({
  declarations: [
    AppComponent,
    Shape01Component,
    Shape02Component,
    Shape03Component,
    Shape04Component,
    Shape05Component
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
