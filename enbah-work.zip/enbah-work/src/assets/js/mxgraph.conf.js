mxBasePath = '../../../node_modules/mxgraph/javascript/src';
