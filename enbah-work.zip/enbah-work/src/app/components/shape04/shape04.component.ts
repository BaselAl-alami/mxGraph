import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shape04',
  templateUrl: './shape04.component.html',
  styleUrls: ['./shape04.component.css']
})
export class Shape04Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
