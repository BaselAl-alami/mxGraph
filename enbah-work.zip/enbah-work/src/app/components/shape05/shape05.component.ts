import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shape05',
  templateUrl: './shape05.component.html',
  styleUrls: ['./shape05.component.css']
})
export class Shape05Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
